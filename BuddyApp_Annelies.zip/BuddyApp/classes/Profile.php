<?php 

class Profile implements iProfile{
    private $username;
    private $email;

    public function setUsername($username){
        if(empty($username)){
            throw new Exception("Username cannot be empty");
        }
        $this->username = $username;
    }

    public function getUsername($username){
        return $this->username;
    }

    public function setEmail(){

    }

    public function getEmail(){

    }
}