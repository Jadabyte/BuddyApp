<?php

interface iProfile{
    public function nameChange();

    /*public function avatarChange(){

    };
   public function bioChange(){

    };

    public function passChange(){

    };

    public function emailChange(){

    };*/
}